
/**
 * Created by IntelliJ IDEA.
 * User: nrjs
 * Date: Oct 26, 2005
 * Time: 9:12:42 PM
 * To change this template use File | Settings | File Templates.
 */
public interface Servlet
{
    void service(Request request, Response response);
}
