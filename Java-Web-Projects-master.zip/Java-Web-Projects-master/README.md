Java-Web-Projects
=================

Web Server

- Run through terminal java -jar webserver.jar

- Icons folder and mime.types file are needed in the same folder as the .jar file or server will not work correctly

- Connect to server using localhost:8020


Online Store
